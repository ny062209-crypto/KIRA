# សៀវភៅណែនាំអំពីការ Build កម្មវិធី Android KIRA Auto Post

បង្កើតឡើងដោយ: **KIRA Gaming**

គម្រោងនេះជា Native Android Project សុទ្ធសាធ (100% Kotlin + Jetpack Compose + Material3 + Gradle)។

---

## របៀបបើក និង Build ក្នុង Android Studio

1. **ទាញយក Android Studio**:
   - ត្រូវប្រាកដថាអ្នកប្រើប្រាស់ Android Studio Iguana, Jellyfish, Koala, ឬថ្មីជាងនេះ (JDK 17)។
2. **បើក Project (Open Project)**:
   - ពន្លាឯកសារ ZIP: `KIRA_Auto_Post_Android_Project.zip`
   - ក្នុង Android Studio ចុច **File > Open...** ហើយជ្រើសរើស Folder នៃគម្រោងនេះ។
3. **រង់ចាំ Gradle Sync**:
   - រង់ចាំឱ្យ Gradle Sync បញ្ចប់ដោយជោគជ័យ (ប្រហែល ១ ទៅ ២ នាទី)។
4. **Build APK**:
   - ចុចលើ Menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**
   - នៅពេល Build ចប់រួចរាល់ នឹងមានសារលោតបង្ហាញនៅជ្រុងស្តាំក្រោម **«locate»** ដើម្បីទៅកាន់ Folder ដែលមានឯកសារ `app-debug.apk`។
5. **ដំឡើងលើទូរស័ព្ទ Android**:
   - ចម្លងឯកសារ `app-debug.apk` ទៅកាន់ទូរស័ព្ទដៃ Android (Android 7.0 / SDK 24 ឡើងទៅ) រួចចុច Install។

---

## របៀប Build តាម Command Line (Terminal)

```bash
# អនុញ្ញាតសិទ្ធិដំណើរការ Gradle Wrapper
chmod +x gradlew

# Build Debug APK
./gradlew clean assembleDebug --stacktrace
```

ឯកសារ APK នឹងស្ថិតនៅត្រង់ទីតាំង:
`app/build/outputs/apk/debug/app-debug.apk`

---

## របៀប Build តាម GitHub Actions (Online មិនចាំបាច់មានកុំព្យូទ័រខ្លាំង)

1. បង្កើត GitHub Repository ថ្មីមួយ
2. Push កូដទាំងអស់ទៅកាន់ Repository នោះ
3. ចូលទៅកាន់ Tab **Actions** នៅលើ GitHub
4. ជ្រើសរើស Workflow **«Build KIRA Auto Post APK»** រួចចុច **Run workflow**
5. នៅពេលបញ្ចប់ អ្នកអាចទាញយក `app-debug.apk` ពីផ្នែក **Artifacts** បានភ្លាមៗ!
