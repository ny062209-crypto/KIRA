# របៀបដំឡើង Telegram Engine Server (Telethon) សម្រាប់ KIRA Auto Post

បង្កើតឡើងដោយ: **KIRA Gaming**

Telegram Engine Server នេះប្រើប្រាស់បណ្ណាល័យផ្លូវការ **Telethon (MTProto)** ជាមួយ **FastAPI** ដើម្បីធ្វើការផ្ញើសារ រូបភាព វីដេអូ និងឯកសារចូលទៅក្នុងក្រុម និងប៉ុស្តិ៍ Telegram ដោយសុវត្ថិភាព 100% មិនមែនជា Demo ឬ Mock Data ឡើយ។

---

## ជម្រើសទី ១: ដំឡើងលើ VPS (Ubuntu / Debian) ជាមួយ Docker (ងាយស្រួលបំផុត)

### ជំហានទី ១: ចូលទៅកាន់ VPS របស់អ្នកតាម SSH
```bash
ssh root@YOUR_VPS_IP
```

### ជំហានទី ២: ដំឡើង Docker & Git (ប្រសិនបើមិនទាន់មាន)
```bash
apt update && apt install -y docker.io docker-compose git
```

### ជំហានទី ៣: បង្កើត Folder សម្រាប់ Server
```bash
mkdir -p /root/kira-engine && cd /root/kira-engine
```

ចម្លងឯកសារ `main.py`, `requirements.txt`, និង `Dockerfile` មកដាក់ក្នុង folder នេះ។

### ជំហានទី ៤: Build និង Run Docker Container
```bash
docker build -t kira-telethon-engine .
docker run -d --name kira-engine --restart always -p 8000:8000 -e KIRA_SECURITY_TOKEN="kira-secret-token" kira-telethon-engine
```

### ជំហានទី ៥: ពិនិត្យមើលស្ថានភាព Server
```bash
curl http://localhost:8000/health
```
លទ្ធផលនឹងបង្ហាញ: `{"status":"ok","engine":"telethon","app":"KIRA Auto Post"}`

---

## ជម្រើសទី ២: ដំឡើងដោយផ្ទាល់ជាមួយ Python Systemd Service

### ជំហានទី ១: ដំឡើង Python 3.11 & Pip
```bash
apt update && apt install -y python3 python3-pip python3-venv
```

### ជំហានទី ២: បង្កើត Virtual Environment និងដំឡើង Library
```bash
mkdir -p /opt/kira-engine && cd /opt/kira-engine
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### ជំហានទី ៣: បង្កើត Systemd Service ដើម្បីឱ្យដំណើរការរហូត (Auto Start)
បង្កើតឯកសារ `/etc/systemd/system/kira-engine.service`:
```ini
[Unit]
Description=KIRA Auto Post Telegram Engine
After=network.target

[Service]
User=root
WorkingDirectory=/opt/kira-engine
Environment="KIRA_SECURITY_TOKEN=kira-secret-token"
ExecStart=/opt/kira-engine/venv/bin/uvicorn main:app --host 0.0.0.0 --port 8000
Restart=always

[Install]
WantedBy=multi-user.target
```

ដំណើរការ Service:
```bash
systemctl daemon-reload
systemctl enable --now kira-engine
systemctl status kira-engine
```

---

## របៀបភ្ជាប់ក្នុង App Android KIRA Auto Post

1. បើក App **KIRA Auto Post** លើទូរស័ព្ទដៃ
2. ចូលទៅកាន់ **ការកំណត់ (Settings)**
3. ក្នុងប្រអប់ **Server URL**:
   - ប្រសិនបើតេស្តលើ Emulator: `http://10.0.2.2:8000`
   - ប្រសិនបើតេស្តលើ WiFi ផ្ទះ: `http://192.168.x.x:8000`
   - ប្រសិនបើប្រើ VPS: `http://YOUR_VPS_IP:8000` (ឬ HTTPS Domain)
4. ក្នុងប្រអប់ **Security Token**: វាយបញ្ចូល `kira-secret-token` (ឬ token ដែលអ្នកបានកំណត់)
5. ចុចប៊ូតុង **«តេស្តការតភ្ជាប់ (Test Connection)»** ដើម្បីបញ្ជាក់ការតភ្ជាប់។
