package com.kiragaming.kiraautopost.data

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.kiragaming.kiraautopost.model.SendLogItem
import com.kiragaming.kiraautopost.model.SendStatus
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ReportStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("kira_reports", Context.MODE_PRIVATE)
    private val gson = Gson()
    private val key = "post_logs"

    fun getAllLogs(): List<SendLogItem> {
        val json = prefs.getString(key, null) ?: return emptyList()
        val type = object : TypeToken<List<SendLogItem>>() {}.type
        return try {
            gson.fromJson(json, type) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun addLog(log: SendLogItem) {
        val current = getAllLogs().toMutableList()
        current.add(0, log) // newest first
        if (current.size > 1000) {
            current.subList(1000, current.size).clear()
        }
        val json = gson.toJson(current)
        prefs.edit().putString(key, json).apply()
    }

    fun clearLogs() {
        prefs.edit().remove(key).apply()
    }

    fun getFailedOnly(): List<SendLogItem> {
        return getAllLogs().filter { it.status == SendStatus.FAILED }
    }

    fun exportToCsvFile(): File {
        val logs = getAllLogs()
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        val fileName = "kira_post_report_${System.currentTimeMillis()}.csv"
        val file = File(context.cacheDir, fileName)

        file.printWriter().use { out ->
            out.println("Timestamp,Account,ChatTitle,ChatId,Status,Reason")
            logs.forEach { item ->
                val dateStr = dateFormat.format(Date(item.timestamp))
                val titleEscaped = item.chatTitle.replace("\"", "\"\"")
                val reasonEscaped = item.reason.replace("\"", "\"\"")
                out.println("\"$dateStr\",\"${item.accountPhone}\",\"$titleEscaped\",${item.chatId},\"${item.status}\",\"$reasonEscaped\"")
            }
        }
        return file
    }
}
