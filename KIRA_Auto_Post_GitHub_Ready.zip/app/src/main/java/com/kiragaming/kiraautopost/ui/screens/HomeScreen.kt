package com.kiragaming.kiraautopost.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kiragaming.kiraautopost.R
import com.kiragaming.kiraautopost.data.AccountStore
import com.kiragaming.kiraautopost.data.GroupStore
import com.kiragaming.kiraautopost.data.PreferencesManager
import com.kiragaming.kiraautopost.data.ReportStore
import com.kiragaming.kiraautopost.model.SendStatus
import com.kiragaming.kiraautopost.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    accountStore: AccountStore,
    groupStore: GroupStore,
    reportStore: ReportStore,
    prefs: PreferencesManager,
    onNavigateToAccounts: () -> Unit,
    onNavigateToGroups: () -> Unit,
    onNavigateToPost: () -> Unit,
    onNavigateToReports: () -> Unit,
    onNavigateToSettings: () -> Unit
) {
    val accounts = remember { accountStore.getAllAccounts() }
    val logs = remember { reportStore.getAllLogs() }
    val successCount = logs.count { it.status == SendStatus.SUCCESS }
    val failedCount = logs.count { it.status == SendStatus.FAILED }
    val skippedCount = logs.count { it.status == SendStatus.SKIPPED }

    var totalSelectedGroups = 0
    accounts.forEach { acc ->
        totalSelectedGroups += groupStore.getGroupsForAccount(acc.phone).count { it.isSelected }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(
                            painter = painterResource(id = R.drawable.app_logo),
                            contentDescription = "Logo",
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .border(1.dp, BorderOutline, RoundedCornerShape(8.dp)),
                            contentScale = ContentScale.Fit
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "KIRA Auto Post",
                                style = MaterialTheme.typography.titleLarge.copy(fontSize = 18.sp),
                                color = TextDark
                            )
                            Text(
                                text = stringResource(id = R.string.creator_khmer),
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                                color = TextSecondary
                            )
                        }
                    }
                },
                actions = {
                    IconButton(onClick = onNavigateToSettings) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = PrimaryBlue
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BackgroundWhite)
            )
        },
        containerColor = BackgroundWhite
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Spacer(modifier = Modifier.height(12.dp))

            // Safety Delay Notice Card
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF6FF)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFFBFDBFE), RoundedCornerShape(16.dp))
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .background(PrimaryBlue, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = null,
                            tint = Color.White
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column {
                        Text(
                            text = "ការការពារគណនី (Safe Sending 40s)",
                            style = MaterialTheme.typography.titleMedium.copy(fontSize = 15.sp),
                            color = PrimaryBlue,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "គម្លាតពេលផុស ${prefs.postDelaySeconds} វិនាទី ដើម្បីការពារការ Ban ឬ Flood Wait ពី Telegram",
                            style = MaterialTheme.typography.bodyMedium.copy(fontSize = 13.sp),
                            color = TextDark
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Summary Stats Grid
            Text(
                text = "ស្ថានភាពសរុប (Summary)",
                style = MaterialTheme.typography.titleMedium,
                color = TextDark
            )
            Spacer(modifier = Modifier.height(10.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                // Accounts Card
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .weight(1f)
                        .border(1.dp, BorderOutline, RoundedCornerShape(16.dp))
                        .clickable { onNavigateToAccounts() }
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Person, contentDescription = null, tint = PrimaryBlue, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("គណនី", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "${accounts.size}",
                            style = MaterialTheme.typography.displayLarge.copy(fontSize = 24.sp),
                            color = TextDark
                        )
                        Text("បានតភ្ជាប់", style = MaterialTheme.typography.labelSmall, color = SuccessGreen)
                    }
                }

                // Selected Groups Card
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .weight(1f)
                        .border(1.dp, BorderOutline, RoundedCornerShape(16.dp))
                        .clickable { onNavigateToGroups() }
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Group, contentDescription = null, tint = PrimaryBlue, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("ក្រុមបានជ្រើស", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "$totalSelectedGroups",
                            style = MaterialTheme.typography.displayLarge.copy(fontSize = 24.sp),
                            color = TextDark
                        )
                        Text("ត្រៀមផុស", style = MaterialTheme.typography.labelSmall, color = PrimaryBlue)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Last Campaign Performance Card
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderOutline, RoundedCornerShape(16.dp))
                    .clickable { onNavigateToReports() }
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "លទ្ធផលនៃការផុសកន្លងមក",
                            style = MaterialTheme.typography.titleMedium.copy(fontSize = 15.sp),
                            color = TextDark
                        )
                        Text(
                            text = "មើលរបាយការណ៍ >",
                            style = MaterialTheme.typography.bodyMedium.copy(fontSize = 13.sp),
                            color = PrimaryBlue
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "$successCount", style = MaterialTheme.typography.titleLarge, color = SuccessGreen)
                            Text(text = "ជោគជ័យ", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "$failedCount", style = MaterialTheme.typography.titleLarge, color = ErrorRed)
                            Text(text = "បរាជ័យ", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "$skippedCount", style = MaterialTheme.typography.titleLarge, color = SkippedOrange)
                            Text(text = "រំលង", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Quick Actions
            Text(
                text = "សកម្មភាពរហ័ស (Quick Actions)",
                style = MaterialTheme.typography.titleMedium,
                color = TextDark
            )
            Spacer(modifier = Modifier.height(10.dp))

            Button(
                onClick = onNavigateToPost,
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
            ) {
                Icon(Icons.Default.Send, contentDescription = null, tint = OnPrimary)
                Spacer(modifier = Modifier.width(8.dp))
                Text("ចាប់ផ្តើមផុសសារឥឡូវ (Start Posting)", style = MaterialTheme.typography.labelLarge)
            }

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedButton(
                onClick = onNavigateToAccounts,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, PrimaryBlue),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = PrimaryBlue)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, tint = PrimaryBlue)
                Spacer(modifier = Modifier.width(8.dp))
                Text("បន្ថែមគណនី Telegram ថ្មី", style = MaterialTheme.typography.titleMedium.copy(color = PrimaryBlue, fontSize = 15.sp))
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
