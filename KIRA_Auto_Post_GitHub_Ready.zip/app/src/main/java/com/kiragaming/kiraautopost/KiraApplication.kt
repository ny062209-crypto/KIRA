package com.kiragaming.kiraautopost

import android.app.Application
import com.kiragaming.kiraautopost.data.AccountStore
import com.kiragaming.kiraautopost.data.GroupStore
import com.kiragaming.kiraautopost.data.PreferencesManager
import com.kiragaming.kiraautopost.data.ReportStore
import com.kiragaming.kiraautopost.engine.PostingManager
import com.kiragaming.kiraautopost.engine.TelegramEngine
import com.kiragaming.kiraautopost.engine.remote.TelethonEngine

class KiraApplication : Application() {

    lateinit var preferencesManager: PreferencesManager
        private set
    lateinit var accountStore: AccountStore
        private set
    lateinit var groupStore: GroupStore
        private set
    lateinit var reportStore: ReportStore
        private set
    lateinit var telegramEngine: TelegramEngine
        private set
    lateinit var postingManager: PostingManager
        private set

    override fun onCreate() {
        super.onCreate()
        preferencesManager = PreferencesManager(this)
        accountStore = AccountStore(this)
        groupStore = GroupStore(this)
        reportStore = ReportStore(this)

        telegramEngine = TelethonEngine(
            context = this,
            serverUrlProvider = { preferencesManager.serverUrl },
            serverTokenProvider = { preferencesManager.serverToken }
        )

        postingManager = PostingManager(
            context = this,
            telegramEngine = telegramEngine,
            reportStore = reportStore,
            prefs = preferencesManager
        )
    }
}
