package com.kiragaming.kiraautopost.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kiragaming.kiraautopost.R
import com.kiragaming.kiraautopost.data.AccountStore
import com.kiragaming.kiraautopost.data.GroupStore
import com.kiragaming.kiraautopost.engine.EngineResult
import com.kiragaming.kiraautopost.engine.TelegramEngine
import com.kiragaming.kiraautopost.model.ChatGroup
import com.kiragaming.kiraautopost.model.ChatType
import com.kiragaming.kiraautopost.ui.theme.*
import kotlinx.coroutines.launch
import coil.compose.AsyncImage
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GroupsScreen(
    accountStore: AccountStore,
    groupStore: GroupStore,
    telegramEngine: TelegramEngine
) {
    val coroutineScope = rememberCoroutineScope()
    val accounts = remember { accountStore.getAllAccounts() }

    var selectedAccountPhone by remember {
        mutableStateOf(accounts.firstOrNull()?.phone ?: "")
    }

    var groups by remember {
        mutableStateOf(if (selectedAccountPhone.isNotBlank()) groupStore.getGroupsForAccount(selectedAccountPhone) else emptyList())
    }

    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf<ChatType?>(null) } // null = All
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    fun refreshGroups() {
        if (selectedAccountPhone.isNotBlank()) {
            groups = groupStore.getGroupsForAccount(selectedAccountPhone)
        }
    }

    val filteredGroups = groups.filter { group ->
        val matchesSearch = group.title.contains(searchQuery, ignoreCase = true) ||
                group.username.contains(searchQuery, ignoreCase = true)
        val matchesType = selectedFilter == null || group.type == selectedFilter
        matchesSearch && matchesType
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(
                            painter = painterResource(id = R.drawable.app_logo),
                            contentDescription = "Logo",
                            modifier = Modifier
                                .size(32.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .border(1.dp, BorderOutline, RoundedCornerShape(8.dp)),
                            contentScale = ContentScale.Fit
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "គ្រប់គ្រងក្រុម & ប៉ុស្តិ៍",
                            style = MaterialTheme.typography.titleLarge.copy(fontSize = 18.sp),
                            color = TextDark
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BackgroundWhite)
            )
        },
        containerColor = BackgroundWhite
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            // Account selection chip row if multiple accounts
            if (accounts.size > 1) {
                Text(
                    text = "ជ្រើសរើសគណនី:",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    accounts.forEach { acc ->
                        FilterChip(
                            selected = selectedAccountPhone == acc.phone,
                            onClick = {
                                selectedAccountPhone = acc.phone
                                refreshGroups()
                            },
                            label = { Text(if (acc.firstName.isNotBlank()) acc.firstName else acc.phone) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = PrimaryBlue,
                                selectedLabelColor = OnPrimary
                            )
                        )
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
            }

            // Fetch Chats Button
            Button(
                onClick = {
                    val currentAcc = accounts.find { it.phone == selectedAccountPhone }
                    if (currentAcc == null) {
                        errorMessage = "សូមបន្ថែម ឬជ្រើសរើសគណនី Telegram ជាមុនសិន"
                        return@Button
                    }
                    isLoading = true
                    errorMessage = null
                    coroutineScope.launch {
                        val res = telegramEngine.loadChats(currentAcc)
                        isLoading = false
                        when (res) {
                            is EngineResult.Success -> {
                                groupStore.saveGroupsForAccount(selectedAccountPhone, res.data)
                                refreshGroups()
                            }
                            is EngineResult.Error -> {
                                errorMessage = res.messageKhmer
                            }
                        }
                    }
                },
                enabled = !isLoading && selectedAccountPhone.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
            ) {
                if (isLoading) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("កំពុងទាញយកក្រុម...", style = MaterialTheme.typography.labelLarge)
                } else {
                    Icon(Icons.Default.CloudDownload, contentDescription = null, tint = OnPrimary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(stringResource(id = R.string.load_all_chats), style = MaterialTheme.typography.labelLarge)
                }
            }

            if (errorMessage != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    color = Color(0xFFFEE2E2),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = errorMessage!!,
                        color = ErrorRed,
                        style = MaterialTheme.typography.bodyMedium.copy(fontSize = 13.sp),
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text(stringResource(id = R.string.search_groups)) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TextSecondary) },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Filter Chips & Select All
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(
                        selected = selectedFilter == null,
                        onClick = { selectedFilter = null },
                        label = { Text("ទាំងអស់") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PrimaryBlue,
                            selectedLabelColor = OnPrimary
                        )
                    )
                    FilterChip(
                        selected = selectedFilter == ChatType.SUPERGROUP,
                        onClick = { selectedFilter = ChatType.SUPERGROUP },
                        label = { Text("ក្រុមធំ") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PrimaryBlue,
                            selectedLabelColor = OnPrimary
                        )
                    )
                    FilterChip(
                        selected = selectedFilter == ChatType.CHANNEL,
                        onClick = { selectedFilter = ChatType.CHANNEL },
                        label = { Text("ប៉ុស្តិ៍") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PrimaryBlue,
                            selectedLabelColor = OnPrimary
                        )
                    )
                }

                Row {
                    val allSelected = groups.isNotEmpty() && groups.filter { it.canPost }.all { it.isSelected }
                    TextButton(
                        onClick = {
                            groupStore.selectAllGroups(selectedAccountPhone, !allSelected)
                            refreshGroups()
                        }
                    ) {
                        Text(
                            text = if (allSelected) "ដោះទាំងអស់" else "ជ្រើសទាំងអស់",
                            color = PrimaryBlue,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Groups List
            if (filteredGroups.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = stringResource(id = R.string.no_groups_loaded),
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(filteredGroups, key = { it.id }) { group ->
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (group.isSelected) Color(0xFFF0F7FF) else SurfaceWhite
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(
                                    1.dp,
                                    if (group.isSelected) PrimaryBlue else BorderOutline,
                                    RoundedCornerShape(12.dp)
                                )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = group.isSelected,
                                    onCheckedChange = { checked ->
                                        groupStore.updateGroupSelection(selectedAccountPhone, group.id, checked)
                                        refreshGroups()
                                    },
                                    enabled = group.canPost,
                                    colors = CheckboxDefaults.colors(
                                        checkedColor = PrimaryBlue,
                                        uncheckedColor = TextSecondary
                                    )
                                )

                                Spacer(modifier = Modifier.width(8.dp))

                                GroupAvatar(group = group)

                                Spacer(modifier = Modifier.width(10.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = group.title,
                                        style = MaterialTheme.typography.titleMedium.copy(fontSize = 15.sp),
                                        color = TextDark
                                    )
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = when (group.type) {
                                                ChatType.CHANNEL -> "Channel"
                                                ChatType.SUPERGROUP -> "Supergroup"
                                                ChatType.GROUP -> "Group"
                                            },
                                            style = MaterialTheme.typography.labelSmall,
                                            color = TextSecondary
                                        )
                                        if (group.memberCount > 0) {
                                            Text(
                                                text = " • ${group.memberCount} សមាជិក",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = TextSecondary
                                            )
                                        }
                                    }
                                }

                                if (!group.canPost) {
                                    Surface(
                                        color = Color(0xFFFEE2E2),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            text = stringResource(id = R.string.cannot_post_mark),
                                            color = ErrorRed,
                                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}


@Composable
private fun GroupAvatar(group: ChatGroup) {
    val hasPhoto = group.avatarPath.isNotBlank() && File(group.avatarPath).exists()
    if (hasPhoto) {
        AsyncImage(
            model = File(group.avatarPath),
            contentDescription = group.title,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(46.dp)
                .clip(androidx.compose.foundation.shape.CircleShape)
        )
    } else {
        val colors = listOf(
            Color(0xFF3B82F6), Color(0xFF10B981), Color(0xFFF59E0B),
            Color(0xFF8B5CF6), Color(0xFFEF4444), Color(0xFF14B8A6)
        )
        val bg = colors[(kotlin.math.abs(group.id) % colors.size).toInt()]
        Box(
            modifier = Modifier
                .size(46.dp)
                .clip(androidx.compose.foundation.shape.CircleShape)
                .background(bg),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = group.title.trim().firstOrNull()?.uppercase() ?: "?",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
        }
    }
}
