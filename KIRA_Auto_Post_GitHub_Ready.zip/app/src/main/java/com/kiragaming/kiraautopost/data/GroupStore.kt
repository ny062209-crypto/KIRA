package com.kiragaming.kiraautopost.data

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.kiragaming.kiraautopost.model.ChatGroup

class GroupStore(context: Context) {
    private val prefs = context.getSharedPreferences("kira_groups", Context.MODE_PRIVATE)
    private val gson = Gson()

    fun getGroupsForAccount(phone: String): List<ChatGroup> {
        val json = prefs.getString("groups_$phone", null) ?: return emptyList()
        val type = object : TypeToken<List<ChatGroup>>() {}.type
        return try {
            gson.fromJson(json, type) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveGroupsForAccount(phone: String, groups: List<ChatGroup>) {
        val json = gson.toJson(groups)
        prefs.edit().putString("groups_$phone", json).apply()
    }

    fun updateGroupSelection(phone: String, chatId: Long, selected: Boolean) {
        val current = getGroupsForAccount(phone).map {
            if (it.id == chatId) it.copy(isSelected = selected) else it
        }
        saveGroupsForAccount(phone, current)
    }

    fun selectAllGroups(phone: String, selected: Boolean) {
        val current = getGroupsForAccount(phone).map {
            // Only select if canPost is true
            if (it.canPost) it.copy(isSelected = selected) else it.copy(isSelected = false)
        }
        saveGroupsForAccount(phone, current)
    }
}
