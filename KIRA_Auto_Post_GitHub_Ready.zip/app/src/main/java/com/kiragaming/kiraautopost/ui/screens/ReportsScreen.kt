package com.kiragaming.kiraautopost.ui.screens

import android.content.Intent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.kiragaming.kiraautopost.R
import com.kiragaming.kiraautopost.data.ReportStore
import com.kiragaming.kiraautopost.engine.PostingManager
import com.kiragaming.kiraautopost.model.SendStatus
import com.kiragaming.kiraautopost.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(
    reportStore: ReportStore,
    postingManager: PostingManager
) {
    val context = LocalContext.current
    val progress by postingManager.progress.collectAsState()
    var logs by remember { mutableStateOf(reportStore.getAllLogs()) }
    val dateFormat = remember { SimpleDateFormat("HH:mm:ss", Locale.getDefault()) }

    fun refreshLogs() {
        logs = reportStore.getAllLogs()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(
                            painter = painterResource(id = R.drawable.app_logo),
                            contentDescription = "Logo",
                            modifier = Modifier
                                .size(32.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .border(1.dp, BorderOutline, RoundedCornerShape(8.dp)),
                            contentScale = ContentScale.Fit
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "របាយការណ៍ & វឌ្ឍនភាព",
                            style = MaterialTheme.typography.titleLarge.copy(fontSize = 18.sp),
                            color = TextDark
                        )
                    }
                },
                actions = {
                    IconButton(onClick = {
                        val csvFile = reportStore.exportToCsvFile()
                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/csv"
                            putExtra(Intent.EXTRA_SUBJECT, "KIRA Auto Post Report")
                            putExtra(Intent.EXTRA_TEXT, "របាយការណ៍ផុស Telegram ពី KIRA Auto Post")
                            val uri = androidx.core.content.FileProvider.getUriForFile(
                                context,
                                "${context.packageName}.fileprovider",
                                csvFile
                            )
                            putExtra(Intent.EXTRA_STREAM, uri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        context.startActivity(Intent.createChooser(shareIntent, "ចែករំលែករបាយការណ៍ CSV"))
                    }) {
                        Icon(Icons.Default.Share, contentDescription = "Export CSV", tint = PrimaryBlue)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BackgroundWhite)
            )
        },
        containerColor = BackgroundWhite
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            // Active Campaign Card
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderOutline, RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (progress.isRunning) "កំពុងដំណើរការផុស..." else "ស្ថានភាព: ទំនេរ (Idle)",
                            style = MaterialTheme.typography.titleMedium,
                            color = if (progress.isRunning) PrimaryBlue else TextDark
                        )
                        Text(
                            text = "${progress.current} / ${progress.total}",
                            style = MaterialTheme.typography.titleLarge.copy(fontSize = 17.sp),
                            color = PrimaryBlue
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    val ratio = if (progress.total > 0) progress.current.toFloat() / progress.total else 0f
                    LinearProgressIndicator(
                        progress = { ratio },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = PrimaryBlue,
                        trackColor = SurfaceVariantGray,
                    )

                    if (progress.isRunning) {
                        Spacer(modifier = Modifier.height(10.dp))
                        if (progress.countdownSeconds > 0) {
                            Text(
                                text = "⏳ ផុសក្រុមបន្ទាប់ក្នុង ${progress.countdownSeconds} វិនាទី...",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                color = PrimaryBlue
                            )
                        } else if (progress.currentChatTitle.isNotBlank()) {
                            Text(
                                text = "កំពុងផ្ញើទៅកាន់: ${progress.currentChatTitle}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextDark
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Controls: Pause / Resume / Stop
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (progress.isPaused) {
                                Button(
                                    onClick = { postingManager.resume() },
                                    colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.PlayArrow, contentDescription = null, tint = OnPrimary)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("បន្ត (Resume)")
                                }
                            } else {
                                OutlinedButton(
                                    onClick = { postingManager.pause() },
                                    shape = RoundedCornerShape(8.dp),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, SkippedOrange),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = SkippedOrange),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.Pause, contentDescription = null)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("ផ្អាក (Pause)")
                                }
                            }

                            Button(
                                onClick = {
                                    postingManager.stop()
                                    refreshLogs()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = ErrorRed),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Stop, contentDescription = null, tint = OnPrimary)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("បញ្ឈប់ (Stop)")
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Totals Summary Chips
            val successTotal = logs.count { it.status == SendStatus.SUCCESS }
            val failedTotal = logs.count { it.status == SendStatus.FAILED }
            val skippedTotal = logs.count { it.status == SendStatus.SKIPPED }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    color = Color(0xFFDCFCE7),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "$successTotal", style = MaterialTheme.typography.titleMedium, color = SuccessGreen)
                        Text(text = "ជោគជ័យ", style = MaterialTheme.typography.labelSmall, color = TextDark)
                    }
                }
                Surface(
                    color = Color(0xFFFEE2E2),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "$failedTotal", style = MaterialTheme.typography.titleMedium, color = ErrorRed)
                        Text(text = "បរាជ័យ", style = MaterialTheme.typography.labelSmall, color = TextDark)
                    }
                }
                Surface(
                    color = Color(0xFFFEF3C7),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "$skippedTotal", style = MaterialTheme.typography.titleMedium, color = SkippedOrange)
                        Text(text = "រំលង", style = MaterialTheme.typography.labelSmall, color = TextDark)
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // History header & Clear button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ប្រវត្តិនៃការផុស (Log History)",
                    style = MaterialTheme.typography.titleMedium,
                    color = TextDark
                )
                if (logs.isNotEmpty()) {
                    TextButton(
                        onClick = {
                            reportStore.clearLogs()
                            refreshLogs()
                        }
                    ) {
                        Text("លុបប្រវត្តិ", color = ErrorRed, fontSize = 13.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Log Items List
            if (logs.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "មិនទាន់មានកំណត់ត្រាផុសនៅឡើយទេ",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(logs, key = { it.id }) { item ->
                        val (statusBg, statusColor, statusLabel) = when (item.status) {
                            SendStatus.SUCCESS -> Triple(Color(0xFFDCFCE7), SuccessGreen, "ជោគជ័យ")
                            SendStatus.FAILED -> Triple(Color(0xFFFEE2E2), ErrorRed, "បរាជ័យ")
                            SendStatus.SKIPPED -> Triple(Color(0xFFFEF3C7), SkippedOrange, "រំលង")
                        }

                        Card(
                            colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, BorderOutline, RoundedCornerShape(12.dp))
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = item.chatTitle,
                                        style = MaterialTheme.typography.titleMedium.copy(fontSize = 15.sp),
                                        color = TextDark
                                    )
                                    Surface(
                                        color = statusBg,
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            text = statusLabel,
                                            color = statusColor,
                                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(4.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = item.reason,
                                        style = MaterialTheme.typography.bodyMedium.copy(fontSize = 13.sp),
                                        color = if (item.status == SendStatus.FAILED) ErrorRed else TextSecondary,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Text(
                                        text = dateFormat.format(Date(item.timestamp)),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextSecondary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
