package com.kiragaming.kiraautopost.data

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.kiragaming.kiraautopost.model.TelegramAccount

class AccountStore(context: Context) {
    private val prefs = context.getSharedPreferences("kira_accounts", Context.MODE_PRIVATE)
    private val gson = Gson()
    private val key = "accounts_list"

    fun getAllAccounts(): List<TelegramAccount> {
        val json = prefs.getString(key, null) ?: return emptyList()
        val type = object : TypeToken<List<TelegramAccount>>() {}.type
        return try {
            gson.fromJson(json, type) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveAccount(account: TelegramAccount) {
        val current = getAllAccounts().toMutableList()
        val index = current.indexOfFirst { it.phone == account.phone }
        if (index >= 0) {
            current[index] = account
        } else {
            current.add(account)
        }
        saveAll(current)
    }

    fun removeAccount(phone: String) {
        val current = getAllAccounts().filterNot { it.phone == phone }
        saveAll(current)
    }

    private fun saveAll(accounts: List<TelegramAccount>) {
        val json = gson.toJson(accounts)
        prefs.edit().putString(key, json).apply()
    }
}
