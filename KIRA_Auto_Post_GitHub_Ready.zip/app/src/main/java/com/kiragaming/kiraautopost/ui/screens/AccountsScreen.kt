package com.kiragaming.kiraautopost.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kiragaming.kiraautopost.R
import com.kiragaming.kiraautopost.data.AccountStore
import com.kiragaming.kiraautopost.engine.EngineResult
import com.kiragaming.kiraautopost.engine.TelegramEngine
import com.kiragaming.kiraautopost.model.AccountStatus
import com.kiragaming.kiraautopost.model.TelegramAccount
import com.kiragaming.kiraautopost.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccountsScreen(
    accountStore: AccountStore,
    telegramEngine: TelegramEngine
) {
    val coroutineScope = rememberCoroutineScope()
    var accounts by remember { mutableStateOf(accountStore.getAllAccounts()) }

    var showAddDialog by remember { mutableStateOf(false) }
    var apiId by remember { mutableStateOf("") }
    var apiHash by remember { mutableStateOf("") }
    var phoneNumber by remember { mutableStateOf("") }
    var authCode by remember { mutableStateOf("") }
    var password2FA by remember { mutableStateOf("") }

    var isCodeSent by remember { mutableStateOf(false) }
    var is2FaRequired by remember { mutableStateOf(false) }
    var phoneCodeHash by remember { mutableStateOf("") }
    var deliveryType by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var infoMessage by remember { mutableStateOf<String?>(null) }

    fun refreshAccounts() {
        accounts = accountStore.getAllAccounts()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(
                            painter = painterResource(id = R.drawable.app_logo),
                            contentDescription = "Logo",
                            modifier = Modifier
                                .size(32.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .border(1.dp, BorderOutline, RoundedCornerShape(8.dp)),
                            contentScale = ContentScale.Fit
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = stringResource(id = R.string.account_list),
                            style = MaterialTheme.typography.titleLarge.copy(fontSize = 18.sp),
                            color = TextDark
                        )
                    }
                },
                actions = {
                    FilledTonalButton(
                        onClick = {
                            errorMessage = null
                            infoMessage = null
                            isCodeSent = false
                            is2FaRequired = false
                            authCode = ""
                            password2FA = ""
                            showAddDialog = true
                        },
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = PrimaryBlue,
                            contentColor = OnPrimary
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(stringResource(id = R.string.add_account), fontSize = 13.sp)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BackgroundWhite)
            )
        },
        containerColor = BackgroundWhite
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            if (accounts.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Default.AccountCircle,
                            contentDescription = null,
                            tint = Color(0xFFD1D5DB),
                            modifier = Modifier.size(72.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = stringResource(id = R.string.no_accounts),
                            style = MaterialTheme.typography.bodyLarge,
                            color = TextSecondary,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = { showAddDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(stringResource(id = R.string.add_account))
                        }
                    }
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(accounts, key = { it.phone }) { acc ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, BorderOutline, RoundedCornerShape(16.dp))
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = if (acc.firstName.isNotBlank()) acc.firstName else acc.phone,
                                            style = MaterialTheme.typography.titleMedium,
                                            color = TextDark
                                        )
                                        Text(
                                            text = acc.phone,
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = TextSecondary
                                        )
                                        if (acc.username.isNotBlank()) {
                                            Text(
                                                text = "@${acc.username}",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = PrimaryBlue
                                            )
                                        }
                                    }

                                    // Status Badge
                                    val (badgeBg, badgeText, badgeColor) = when (acc.status) {
                                        AccountStatus.AUTHORIZED -> Triple(Color(0xFFDCFCE7), "ចូលរួចរាល់", SuccessGreen)
                                        AccountStatus.AWAITING_CODE -> Triple(Color(0xFFFEF3C7), "រង់ចាំកូដ", SkippedOrange)
                                        AccountStatus.AWAITING_PASSWORD -> Triple(Color(0xFFFEF3C7), "រង់ចាំ 2FA", SkippedOrange)
                                        AccountStatus.ERROR -> Triple(Color(0xFFFEE2E2), "កំហុស", ErrorRed)
                                        else -> Triple(Color(0xFFF3F4F6), "មិនទាន់ចូល", TextSecondary)
                                    }

                                    Surface(
                                        color = badgeBg,
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.padding(4.dp)
                                    ) {
                                        Text(
                                            text = badgeText,
                                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                            color = badgeColor,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End
                                ) {
                                    TextButton(
                                        onClick = {
                                            accountStore.removeAccount(acc.phone)
                                            refreshAccounts()
                                        },
                                        colors = ButtonDefaults.textButtonColors(contentColor = ErrorRed)
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(stringResource(id = R.string.remove), fontSize = 13.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Add Account Dialog
    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = { if (!isLoading) showAddDialog = false },
            title = {
                Text(
                    text = stringResource(id = R.string.add_account),
                    style = MaterialTheme.typography.titleLarge,
                    color = TextDark
                )
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    if (errorMessage != null) {
                        Surface(
                            color = Color(0xFFFEE2E2),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 8.dp)
                        ) {
                            Text(
                                text = errorMessage!!,
                                color = ErrorRed,
                                style = MaterialTheme.typography.bodyMedium.copy(fontSize = 13.sp),
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }

                    if (infoMessage != null) {
                        Surface(
                            color = Color(0xFFEFF6FF),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 8.dp)
                        ) {
                            Text(
                                text = infoMessage!!,
                                color = PrimaryBlue,
                                style = MaterialTheme.typography.bodyMedium.copy(fontSize = 13.sp),
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }

                    OutlinedTextField(
                        value = apiId,
                        onValueChange = { apiId = it },
                        label = { Text(stringResource(id = R.string.api_id)) },
                        placeholder = { Text("ឧ. 1234567") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !isCodeSent && !isLoading
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = apiHash,
                        onValueChange = { apiHash = it },
                        label = { Text(stringResource(id = R.string.api_hash)) },
                        placeholder = { Text("ឧ. 0123456789abcdef...") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !isCodeSent && !isLoading
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = phoneNumber,
                        onValueChange = { phoneNumber = it },
                        label = { Text(stringResource(id = R.string.phone_number)) },
                        placeholder = { Text("+85512345678") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !isCodeSent && !isLoading
                    )

                    if (!isCodeSent) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = {
                                if (apiId.isBlank() || apiHash.isBlank() || phoneNumber.isBlank()) {
                                    errorMessage = "សូមបំពេញ API ID, API Hash និងលេខទូរស័ព្ទ"
                                    return@Button
                                }
                                isLoading = true
                                errorMessage = null
                                coroutineScope.launch {
                                    val dummyAcc = TelegramAccount(
                                        id = phoneNumber,
                                        phone = phoneNumber,
                                        apiId = apiId,
                                        apiHash = apiHash
                                    )
                                    val res = telegramEngine.sendLoginCode(dummyAcc)
                                    isLoading = false
                                    when (res) {
                                        is EngineResult.Success -> {
                                            phoneCodeHash = res.data.phoneCodeHash
                                            deliveryType = res.data.deliveryType
                                            isCodeSent = true
                                            infoMessage = "លេខកូដត្រូវបានផ្ញើតាមរយៈ $deliveryType"
                                        }
                                        is EngineResult.Error -> {
                                            errorMessage = res.messageKhmer
                                        }
                                    }
                                }
                            },
                            enabled = !isLoading,
                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            if (isLoading) {
                                CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White)
                            } else {
                                Text(stringResource(id = R.string.send_code))
                            }
                        }
                    }

                    if (isCodeSent) {
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedTextField(
                            value = authCode,
                            onValueChange = { authCode = it },
                            label = { Text(stringResource(id = R.string.auth_code)) },
                            placeholder = { Text("បញ្ចូលលេខកូដពី Telegram") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            enabled = !isLoading
                        )

                        if (is2FaRequired) {
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedTextField(
                                value = password2FA,
                                onValueChange = { password2FA = it },
                                label = { Text(stringResource(id = R.string.password_2fa)) },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                                enabled = !isLoading
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = {
                                if (authCode.isBlank()) {
                                    errorMessage = "សូមបញ្ចូលលេខកូដបញ្ជាក់ Telegram"
                                    return@Button
                                }
                                isLoading = true
                                errorMessage = null
                                coroutineScope.launch {
                                    val dummyAcc = TelegramAccount(
                                        id = phoneNumber,
                                        phone = phoneNumber,
                                        apiId = apiId,
                                        apiHash = apiHash
                                    )
                                    if (is2FaRequired) {
                                        val res = telegramEngine.verify2FA(dummyAcc, password2FA)
                                        isLoading = false
                                        when (res) {
                                            is EngineResult.Success -> {
                                                accountStore.saveAccount(
                                                    dummyAcc.copy(
                                                        firstName = res.data.firstName,
                                                        username = res.data.username,
                                                        status = AccountStatus.AUTHORIZED,
                                                        sessionString = res.data.sessionString
                                                    )
                                                )
                                                refreshAccounts()
                                                showAddDialog = false
                                            }
                                            is EngineResult.Error -> {
                                                errorMessage = res.messageKhmer
                                            }
                                        }
                                    } else {
                                        val res = telegramEngine.verifyCode(dummyAcc, phoneCodeHash, authCode)
                                        isLoading = false
                                        when (res) {
                                            is EngineResult.Success -> {
                                                accountStore.saveAccount(
                                                    dummyAcc.copy(
                                                        firstName = res.data.firstName,
                                                        username = res.data.username,
                                                        status = AccountStatus.AUTHORIZED,
                                                        sessionString = res.data.sessionString
                                                    )
                                                )
                                                refreshAccounts()
                                                showAddDialog = false
                                            }
                                            is EngineResult.Error -> {
                                                if (res.code == "2FA_REQUIRED") {
                                                    is2FaRequired = true
                                                    infoMessage = res.messageKhmer
                                                } else {
                                                    errorMessage = res.messageKhmer
                                                }
                                            }
                                        }
                                    }
                                }
                            },
                            enabled = !isLoading,
                            colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            if (isLoading) {
                                CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White)
                            } else {
                                Text(stringResource(id = R.string.btn_login))
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(
                    onClick = { showAddDialog = false },
                    enabled = !isLoading
                ) {
                    Text("បោះបង់", color = TextSecondary)
                }
            },
            containerColor = SurfaceWhite,
            shape = RoundedCornerShape(16.dp)
        )
    }
}
