package com.kiragaming.kiraautopost

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.compose.*
import com.kiragaming.kiraautopost.ui.navigation.BottomNavItems
import com.kiragaming.kiraautopost.ui.navigation.Screen
import com.kiragaming.kiraautopost.ui.screens.*
import com.kiragaming.kiraautopost.ui.theme.*

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val app = application as KiraApplication
        val prefs = app.preferencesManager
        val accountStore = app.accountStore
        val groupStore = app.groupStore
        val reportStore = app.reportStore
        val telegramEngine = app.telegramEngine
        val postingManager = app.postingManager

        setContent {
            KiraAutoPostTheme {
                val navController = rememberNavController()
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentRoute = navBackStackEntry?.destination?.route

                val startDest = if (prefs.hasAcceptedTerms) Screen.Home.route else Screen.Welcome.route

                Scaffold(
                    bottomBar = {
                        if (currentRoute != Screen.Welcome.route && currentRoute != Screen.Settings.route) {
                            NavigationBar(
                                containerColor = BackgroundWhite,
                                tonalElevation = 8.dp
                            ) {
                                BottomNavItems.forEach { screen ->
                                    val isSelected = currentRoute == screen.route
                                    NavigationBarItem(
                                        icon = {
                                            Icon(
                                                imageVector = screen.icon,
                                                contentDescription = screen.titleKhmer,
                                                tint = if (isSelected) PrimaryBlue else TextSecondary
                                            )
                                        },
                                        label = {
                                            Text(
                                                text = screen.titleKhmer,
                                                style = MaterialTheme.typography.labelSmall.copy(
                                                    color = if (isSelected) PrimaryBlue else TextSecondary,
                                                    fontSize = 11.sp
                                                )
                                            )
                                        },
                                        selected = isSelected,
                                        onClick = {
                                            if (currentRoute != screen.route) {
                                                navController.navigate(screen.route) {
                                                    popUpTo(Screen.Home.route) {
                                                        saveState = true
                                                    }
                                                    launchSingleTop = true
                                                    restoreState = true
                                                }
                                            }
                                        },
                                        colors = NavigationBarItemDefaults.colors(
                                            indicatorColor = Color(0xFFEFF6FF)
                                        )
                                    )
                                }
                            }
                        }
                    },
                    containerColor = BackgroundWhite
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(BackgroundWhite)
                            .padding(innerPadding)
                    ) {
                        NavHost(
                            navController = navController,
                            startDestination = startDest
                        ) {
                            composable(Screen.Welcome.route) {
                                WelcomeScreen(
                                    onStartClicked = {
                                        prefs.hasAcceptedTerms = true
                                        navController.navigate(Screen.Home.route) {
                                            popUpTo(Screen.Welcome.route) { inclusive = true }
                                        }
                                    }
                                )
                            }
                            composable(Screen.Home.route) {
                                HomeScreen(
                                    accountStore = accountStore,
                                    groupStore = groupStore,
                                    reportStore = reportStore,
                                    prefs = prefs,
                                    onNavigateToAccounts = { navController.navigate(Screen.Accounts.route) },
                                    onNavigateToGroups = { navController.navigate(Screen.Groups.route) },
                                    onNavigateToPost = { navController.navigate(Screen.Post.route) },
                                    onNavigateToReports = { navController.navigate(Screen.Reports.route) },
                                    onNavigateToSettings = { navController.navigate(Screen.Settings.route) }
                                )
                            }
                            composable(Screen.Accounts.route) {
                                AccountsScreen(
                                    accountStore = accountStore,
                                    telegramEngine = telegramEngine
                                )
                            }
                            composable(Screen.Groups.route) {
                                GroupsScreen(
                                    accountStore = accountStore,
                                    groupStore = groupStore,
                                    telegramEngine = telegramEngine
                                )
                            }
                            composable(Screen.Post.route) {
                                PostScreen(
                                    accountStore = accountStore,
                                    groupStore = groupStore,
                                    prefs = prefs,
                                    postingManager = postingManager,
                                    onNavigateToReports = { navController.navigate(Screen.Reports.route) }
                                )
                            }
                            composable(Screen.Reports.route) {
                                ReportsScreen(
                                    reportStore = reportStore,
                                    postingManager = postingManager
                                )
                            }
                            composable(Screen.Settings.route) {
                                SettingsScreen(
                                    prefs = prefs,
                                    telegramEngine = telegramEngine,
                                    onBackClicked = { navController.popBackStack() }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
