package com.kiragaming.kiraautopost.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(val route: String, val titleKhmer: String, val icon: ImageVector) {
    object Welcome : Screen("welcome", "ស្វាគមន៍", Icons.Default.Info)
    object Home : Screen("home", "ទំព័រដើម", Icons.Default.Home)
    object Accounts : Screen("accounts", "គណនី", Icons.Default.Person)
    object Groups : Screen("groups", "ក្រុម", Icons.Default.Group)
    object Post : Screen("post", "ផុស", Icons.Default.Send)
    object Reports : Screen("reports", "របាយការណ៍", Icons.Default.Assessment)
    object Settings : Screen("settings", "ការកំណត់", Icons.Default.Settings)
}

val BottomNavItems = listOf(
    Screen.Home,
    Screen.Accounts,
    Screen.Groups,
    Screen.Post,
    Screen.Reports
)
