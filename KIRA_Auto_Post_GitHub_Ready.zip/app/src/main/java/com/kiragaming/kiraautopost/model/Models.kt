package com.kiragaming.kiraautopost.model

enum class AccountStatus {
    LOGGED_OUT,
    AWAITING_CODE,
    AWAITING_PASSWORD,
    AUTHORIZED,
    ERROR
}

enum class ChatType {
    GROUP,
    SUPERGROUP,
    CHANNEL
}

enum class MediaType {
    IMAGE,
    VIDEO,
    DOCUMENT
}

enum class SendStatus {
    SUCCESS,
    FAILED,
    SKIPPED
}

data class TelegramAccount(
    val id: String,
    val phone: String,
    val apiId: String,
    val apiHash: String,
    val firstName: String = "",
    val username: String = "",
    val status: AccountStatus = AccountStatus.LOGGED_OUT,
    val sessionString: String = "",
    val errorMessage: String = "",
    val lastActive: Long = System.currentTimeMillis()
)

data class ChatGroup(
    val id: Long,
    val title: String,
    val username: String = "",
    val type: ChatType = ChatType.GROUP,
    val canPost: Boolean = true,
    val memberCount: Int = 0,
    val isSelected: Boolean = false,
    val avatarPath: String = ""
)

data class PostMedia(
    val uriString: String,
    val type: MediaType,
    val fileName: String,
    val fileSize: Long = 0L
)

data class SendLogItem(
    val id: String = java.util.UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val chatTitle: String,
    val chatId: Long,
    val accountPhone: String,
    val status: SendStatus,
    val reason: String
)

data class CampaignProgress(
    val total: Int = 0,
    val current: Int = 0,
    val success: Int = 0,
    val failed: Int = 0,
    val skipped: Int = 0,
    val isRunning: Boolean = false,
    val isPaused: Boolean = false,
    val currentChatTitle: String = "",
    val countdownSeconds: Int = 0,
    val activeAccountPhone: String = "",
    val startTime: Long = 0L
)
