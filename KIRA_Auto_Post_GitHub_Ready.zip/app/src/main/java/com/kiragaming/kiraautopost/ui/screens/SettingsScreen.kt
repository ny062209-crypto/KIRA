package com.kiragaming.kiraautopost.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kiragaming.kiraautopost.R
import com.kiragaming.kiraautopost.data.PreferencesManager
import com.kiragaming.kiraautopost.engine.TelegramEngine
import com.kiragaming.kiraautopost.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    prefs: PreferencesManager,
    telegramEngine: TelegramEngine,
    onBackClicked: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()

    var serverUrl by remember { mutableStateOf(prefs.serverUrl) }
    var serverToken by remember { mutableStateOf(prefs.serverToken) }
    var postDelay by remember { mutableIntStateOf(prefs.postDelaySeconds) }
    var randomDelay by remember { mutableStateOf(prefs.enableRandomDelay) }
    var maxPerHour by remember { mutableIntStateOf(prefs.maxPerHour) }
    var dailyLimit by remember { mutableIntStateOf(prefs.dailyLimit) }
    var appLock by remember { mutableStateOf(prefs.appLockEnabled) }

    var showToken by remember { mutableStateOf(false) }
    var isCheckingHealth by remember { mutableStateOf(false) }
    var healthStatus by remember { mutableStateOf<Boolean?>(null) }
    var showGuideDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = stringResource(id = R.string.settings_title),
                        style = MaterialTheme.typography.titleLarge.copy(fontSize = 18.sp),
                        color = TextDark
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBackClicked) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = PrimaryBlue)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BackgroundWhite)
            )
        },
        containerColor = BackgroundWhite
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Spacer(modifier = Modifier.height(12.dp))

            // Telegram Engine Backend Settings
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderOutline, RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Telegram Engine Server (Telethon)",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextDark
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "អាសយដ្ឋាន Server សម្រាប់ដំណើរការតភ្ជាប់ Telegram API",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = serverUrl,
                        onValueChange = {
                            serverUrl = it
                            prefs.serverUrl = it
                        },
                        label = { Text("Server URL") },
                        placeholder = { Text("https://kira-server-xxxx.onrender.com") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = serverToken,
                        onValueChange = {
                            serverToken = it
                            prefs.serverToken = it
                        },
                        label = { Text("Security Token") },
                        singleLine = true,
                        visualTransformation = if (showToken) androidx.compose.ui.text.input.VisualTransformation.None else androidx.compose.ui.text.input.PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { showToken = !showToken }) {
                                Icon(
                                    if (showToken) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = "Show/Hide",
                                    tint = PrimaryBlue
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "ចុចតេស្តការតភ្ជាប់ មុនផ្ញើលេខកូដ ដើម្បីដាស់ Server (Server ឥតគិតថ្លៃអាចដេកលក់ ត្រូវរង់ចាំរហូតដល់ ១ នាទី)",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = {
                                isCheckingHealth = true
                                healthStatus = null
                                coroutineScope.launch {
                                    val isOk = telegramEngine.checkServerHealth()
                                    isCheckingHealth = false
                                    healthStatus = isOk
                                }
                            },
                            shape = RoundedCornerShape(8.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, PrimaryBlue),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = PrimaryBlue)
                        ) {
                            if (isCheckingHealth) {
                                CircularProgressIndicator(modifier = Modifier.size(16.dp), color = PrimaryBlue)
                                Spacer(modifier = Modifier.width(6.dp))
                            }
                            Text("តេស្តការតភ្ជាប់ (Test Connection)", fontSize = 13.sp)
                        }

                        if (healthStatus != null) {
                            Text(
                                text = if (healthStatus == true) "✓ ភ្ជាប់បានជោគជ័យ" else "✕ មិនអាចភ្ជាប់បាន",
                                color = if (healthStatus == true) SuccessGreen else ErrorRed,
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Safe Delay & Speed Limits
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderOutline, RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "កម្រិតសុវត្ថិភាព និងល្បឿនផុស",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextDark
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("គម្លាតពេលផុសលំនាំដើម: $postDelay វិនាទី", style = MaterialTheme.typography.bodyMedium)
                    }

                    Slider(
                        value = postDelay.toFloat(),
                        onValueChange = {
                            val v = it.toInt().coerceAtLeast(10)
                            postDelay = v
                            prefs.postDelaySeconds = v
                        },
                        valueRange = 10f..180f,
                        steps = 17,
                        colors = SliderDefaults.colors(thumbColor = PrimaryBlue, activeTrackColor = PrimaryBlue)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("គម្លាតចៃដន្យ (+/- 5 វិនាទី)", style = MaterialTheme.typography.bodyMedium)
                        Switch(
                            checked = randomDelay,
                            onCheckedChange = {
                                randomDelay = it
                                prefs.enableRandomDelay = it
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = PrimaryBlue)
                        )
                    }

                    Divider(modifier = Modifier.padding(vertical = 8.dp), color = BorderOutline)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("សោការពារកម្មវិធី (PIN / Biometric)", style = MaterialTheme.typography.bodyMedium)
                        Switch(
                            checked = appLock,
                            onCheckedChange = {
                                appLock = it
                                prefs.appLockEnabled = it
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = PrimaryBlue)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Step by Step Telegram API ID Guide Button
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF0FDF4)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFFBBF7D0), RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = stringResource(id = R.string.telegram_guide_title),
                        style = MaterialTheme.typography.titleMedium,
                        color = SuccessGreen
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = stringResource(id = R.string.telegram_guide_content),
                        style = MaterialTheme.typography.bodyMedium.copy(fontSize = 13.sp),
                        color = TextDark
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // About Section
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderOutline, RoundedCornerShape(16.dp))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.app_logo),
                        contentDescription = "Logo",
                        modifier = Modifier
                            .size(72.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .border(1.dp, BorderOutline, RoundedCornerShape(16.dp)),
                        contentScale = ContentScale.Fit
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "KIRA Auto Post",
                        style = MaterialTheme.typography.titleLarge,
                        color = TextDark
                    )
                    Text(
                        text = stringResource(id = R.string.about_version),
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = stringResource(id = R.string.creator_khmer),
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                        color = PrimaryBlue
                    )
                    Text(
                        text = stringResource(id = R.string.creator_en),
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
