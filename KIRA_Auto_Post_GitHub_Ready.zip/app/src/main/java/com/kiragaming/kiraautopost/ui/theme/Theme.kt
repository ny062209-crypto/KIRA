package com.kiragaming.kiraautopost.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.kiragaming.kiraautopost.R

val PrimaryBlue = Color(0xFF2F80ED)
val OnPrimary = Color(0xFFFFFFFF)
val BackgroundWhite = Color(0xFFFFFFFF)
val SurfaceWhite = Color(0xFFFFFFFF)
val SurfaceVariantGray = Color(0xFFF5F7FA)
val TextDark = Color(0xFF1F2937)
val TextSecondary = Color(0xFF4B5563)
val BorderOutline = Color(0xFFE5E7EB)
val ErrorRed = Color(0xFFDC2626)
val SuccessGreen = Color(0xFF16A34A)
val SkippedOrange = Color(0xFFF59E0B)

val NotoSansKhmerFamily = FontFamily(
    Font(R.font.noto_sans_khmer, FontWeight.Normal),
    Font(R.font.noto_sans_khmer_bold, FontWeight.Bold)
)

val KiraTypography = Typography(
    displayLarge = TextStyle(
        fontFamily = NotoSansKhmerFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 28.sp,
        color = TextDark,
        lineHeight = 36.sp
    ),
    headlineMedium = TextStyle(
        fontFamily = NotoSansKhmerFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 22.sp,
        color = TextDark,
        lineHeight = 30.sp
    ),
    titleLarge = TextStyle(
        fontFamily = NotoSansKhmerFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 19.sp,
        color = TextDark,
        lineHeight = 26.sp
    ),
    titleMedium = TextStyle(
        fontFamily = NotoSansKhmerFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 17.sp,
        color = TextDark,
        lineHeight = 24.sp
    ),
    bodyLarge = TextStyle(
        fontFamily = NotoSansKhmerFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 15.sp,
        color = TextDark,
        lineHeight = 22.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = NotoSansKhmerFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        color = TextSecondary,
        lineHeight = 20.sp
    ),
    labelLarge = TextStyle(
        fontFamily = NotoSansKhmerFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 15.sp,
        color = OnPrimary
    ),
    labelSmall = TextStyle(
        fontFamily = NotoSansKhmerFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 12.sp,
        color = TextSecondary
    )
)

private val LightColorScheme = lightColorScheme(
    primary = PrimaryBlue,
    onPrimary = OnPrimary,
    background = BackgroundWhite,
    onBackground = TextDark,
    surface = SurfaceWhite,
    onSurface = TextDark,
    surfaceVariant = SurfaceVariantGray,
    onSurfaceVariant = TextSecondary,
    outline = BorderOutline,
    error = ErrorRed,
    onError = Color.White
)

@Composable
fun KiraAutoPostTheme(content: @Composable () -> Unit) {
    // Strictly white design theme as requested
    MaterialTheme(
        colorScheme = LightColorScheme,
        typography = KiraTypography,
        content = content
    )
}
