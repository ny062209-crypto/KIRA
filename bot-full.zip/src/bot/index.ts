import type { Telegraf } from "telegraf";
import { logger } from "../lib/logger";
import { createBot } from "./factory";
import { getCloneBots, getCloneBotById } from "./db-helpers";
import type { CloneBot } from "@workspace/db";

const runningBots = new Map<string, Telegraf>();

async function startBot(token: string, cloneBotId: number | null, password?: string) {
  if (runningBots.has(token)) return;
  try {
    const bot = createBot(token, cloneBotId, password);
    runningBots.set(token, bot);
    bot.launch({ dropPendingUpdates: true }).catch((err) => {
      logger.error({ err, cloneBotId }, "Bot launch error");
      runningBots.delete(token);
    });
    const info = await bot.telegram.getMe();
    logger.info({ username: info.username, cloneBotId }, "Bot started");
  } catch (err) {
    logger.error({ err, cloneBotId }, "Failed to start bot");
    runningBots.delete(token);
  }
}

function stopBot(token: string) {
  const bot = runningBots.get(token);
  if (bot) {
    bot.stop();
    runningBots.delete(token);
    logger.info({ token: token.slice(0, 10) }, "Bot stopped");
  }
}

export async function startAllBots() {
  const mainToken = process.env["TELEGRAM_BOT_TOKEN"];
  if (!mainToken) {
    logger.warn("TELEGRAM_BOT_TOKEN not set — Telegram bot will not start");
    return;
  }

  await startBot(mainToken, null);

  const clones = await getCloneBots();
  for (const clone of clones) {
    await startBot(clone.token, clone.id, clone.password);
  }

  process.on("clone_bot_added" as any, async (clone: CloneBot) => {
    logger.info({ id: clone.id }, "Starting new clone bot");
    await startBot(clone.token, clone.id, clone.password);
  });

  process.on("clone_bot_removed" as any, async (id: number) => {
    const clone = await getCloneBotById(id);
    if (clone) {
      stopBot(clone.token);
      logger.info({ id }, "Clone bot stopped and removed");
    }
  });
}

export async function stopAllBots() {
  for (const [token] of runningBots) {
    stopBot(token);
  }
}
