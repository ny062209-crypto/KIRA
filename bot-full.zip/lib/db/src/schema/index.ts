import {
  pgTable,
  serial,
  text,
  integer,
  boolean,
  timestamp,
  numeric,
} from "drizzle-orm/pg-core";

export const cloneBots = pgTable("clone_bots", {
  id: serial("id").primaryKey(),
  token: text("token").notNull().unique(),
  botUsername: text("bot_username"),
  ownerTelegramId: text("owner_telegram_id").notNull(),
  password: text("password").notNull(),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  telegramId: text("telegram_id").notNull().unique(),
  username: text("username"),
  firstName: text("first_name"),
  lastName: text("last_name"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const botUsers = pgTable("bot_users", {
  id: serial("id").primaryKey(),
  cloneBotId: integer("clone_bot_id").references(() => cloneBots.id),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id),
  balance: numeric("balance", { precision: 14, scale: 4 })
    .notNull()
    .default("0"),
  referrerId: integer("referrer_id").references(() => users.id),
  joinedAt: timestamp("joined_at").notNull().defaultNow(),
});

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  cloneBotId: integer("clone_bot_id").references(() => cloneBots.id),
  name: text("name").notNull(),
  description: text("description"),
  price: numeric("price", { precision: 14, scale: 4 }).notNull(),
  totalStock: integer("total_stock").notNull().default(0),
  availableStock: integer("available_stock").notNull().default(0),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const productStocks = pgTable("product_stocks", {
  id: serial("id").primaryKey(),
  productId: integer("product_id")
    .notNull()
    .references(() => products.id),
  content: text("content").notNull(),
  isUsed: boolean("is_used").notNull().default(false),
  buyerUserId: integer("buyer_user_id").references(() => users.id),
  soldAt: timestamp("sold_at"),
});

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  cloneBotId: integer("clone_bot_id").references(() => cloneBots.id),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id),
  productId: integer("product_id")
    .notNull()
    .references(() => products.id),
  stockId: integer("stock_id").references(() => productStocks.id),
  productName: text("product_name").notNull(),
  amount: numeric("amount", { precision: 14, scale: 4 }).notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  cloneBotId: integer("clone_bot_id").references(() => cloneBots.id),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id),
  amount: numeric("amount", { precision: 14, scale: 4 }).notNull(),
  type: text("type").notNull(),
  description: text("description"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const promoCodes = pgTable("promo_codes", {
  id: serial("id").primaryKey(),
  cloneBotId: integer("clone_bot_id").references(() => cloneBots.id),
  code: text("code").notNull(),
  amountPerUse: numeric("amount_per_use", { precision: 14, scale: 4 }).notNull(),
  maxUses: integer("max_uses").notNull(),
  usedCount: integer("used_count").notNull().default(0),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const promoCodeUses = pgTable("promo_code_uses", {
  id: serial("id").primaryKey(),
  codeId: integer("code_id")
    .notNull()
    .references(() => promoCodes.id),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id),
  usedAt: timestamp("used_at").notNull().defaultNow(),
});

export const channelRewards = pgTable("channel_rewards", {
  id: serial("id").primaryKey(),
  cloneBotId: integer("clone_bot_id").references(() => cloneBots.id),
  channelLink: text("channel_link").notNull(),
  channelUsername: text("channel_username"),
  channelChatId: text("channel_chat_id"),
  amount: numeric("amount", { precision: 14, scale: 4 }).notNull(),
  description: text("description"),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const channelRewardClaims = pgTable("channel_reward_claims", {
  id: serial("id").primaryKey(),
  rewardId: integer("reward_id")
    .notNull()
    .references(() => channelRewards.id),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id),
  claimedAt: timestamp("claimed_at").notNull().defaultNow(),
});

export const user2faKeys = pgTable("user_2fa_keys", {
  id: serial("id").primaryKey(),
  cloneBotId: integer("clone_bot_id").references(() => cloneBots.id),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id),
  name: text("name").notNull(),
  secret: text("secret").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const botSettings = pgTable("bot_settings", {
  id: serial("id").primaryKey(),
  cloneBotId: integer("clone_bot_id").references(() => cloneBots.id),
  key: text("key").notNull(),
  value: text("value"),
});

export type User = typeof users.$inferSelect;
export type BotUser = typeof botUsers.$inferSelect;
export type Product = typeof products.$inferSelect;
export type ProductStock = typeof productStocks.$inferSelect;
export type Order = typeof orders.$inferSelect;
export type Transaction = typeof transactions.$inferSelect;
export type PromoCode = typeof promoCodes.$inferSelect;
export type ChannelReward = typeof channelRewards.$inferSelect;
export type CloneBot = typeof cloneBots.$inferSelect;
